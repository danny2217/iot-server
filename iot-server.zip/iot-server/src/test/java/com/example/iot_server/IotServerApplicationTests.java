package com.example.iot_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IotServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
